package com.cg.payroll.services;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;

public class PayrollServicesImpl {

	private PayrollDAOServicesImpl daoServicesImpl;

	public PayrollServicesImpl(){
		daoServicesImpl = new PayrollDAOServicesImpl();
	}
	public int acceptAssociateDetails(String firstName,String lastName,String emailId,
			String department,String designation,String pancard,double yearlyInvestmentUnder80C,
			double basicSalary,double epf,double companyPf,int accountNumber,String bankName,String ifscCode){

		Associate associate = new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode));	
		int associateId=daoServicesImpl.insertAssociate(associate);
		return associateId;

	}
	public double calculateNetSalary(int associateId){
		Associate associate =this.getAssociateDetails(associateId);
		if(associate!=null){

			associate.getSalary().setPersonalAllowance((double)0.3*(associate.getSalary().getBasicSalary()));
			associate.getSalary().setConveyenceAllowance((double)0.2*(associate.getSalary().getBasicSalary()));
			associate.getSalary().setOtherAllowance((double)0.1*(associate.getSalary().getBasicSalary()));
			associate.getSalary().setHra((double)0.25*(associate.getSalary().getBasicSalary()));
			associate.getSalary().setGratuity((double)0.05*(associate.getSalary().getBasicSalary()));

			associate.getSalary().setGrossSalary(associate.getSalary().getBasicSalary()+associate.getSalary().getPersonalAllowance()+
					associate.getSalary().getConveyenceAllowance()+associate.getSalary().getOtherAllowance()+
					associate.getSalary().getHra()+associate.getSalary().getCompanyPf());
			double	grossAnnualSalary = 12*(associate.getSalary().getGrossSalary());

			double temp = associate.getYearlyInvestmentUnder80C()+associate.getSalary().getEpf()+associate.getSalary().getCompanyPf();
			double annualTaxPayment = 0.0;
			
			if(temp>150000){
				temp = 1500000;
				if (grossAnnualSalary > 0 && grossAnnualSalary <= 2500000)
					annualTaxPayment = 0 * grossAnnualSalary;
				
				if (grossAnnualSalary > 250000 && grossAnnualSalary <= 500000){
					if((grossAnnualSalary-250000-temp) < 0)
						annualTaxPayment = 0;
					else
					annualTaxPayment = 0.1*(grossAnnualSalary-250000-temp);
				}
				if (grossAnnualSalary >=500000 && grossAnnualSalary <= 1000000)
					annualTaxPayment =((0*250000)+(0.1*(250000-temp))+(0.2*(grossAnnualSalary-500000)));
				if (grossAnnualSalary >=1000000)
					annualTaxPayment =((0*250000)+(0.1*(250000-temp))+(0.2*(grossAnnualSalary-500000))+(0.3*(grossAnnualSalary-1000000)));

			}

				associate.getSalary().setMonthlyTax((double)annualTaxPayment/12);	
				associate.getSalary().setNetSalary((double)(associate.getSalary().getGrossSalary()-associate.getSalary().getMonthlyTax()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()));
				daoServicesImpl.updateAssociate(associate);
				return associate.getSalary().getNetSalary();
			

		}
		return 0;
	}


	public Associate getAssociateDetails(int associateId){
		return 	daoServicesImpl.getAssociate(associateId);

	}

	public Associate[]getAllAssociatesDetails(){
		return daoServicesImpl.getAssociate();
	}
	public boolean updateAssociate(Associate associate){
		return daoServicesImpl.updateAssociate(associate);
	}

}

