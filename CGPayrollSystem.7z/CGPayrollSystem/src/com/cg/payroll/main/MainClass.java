package com.cg.payroll.main;
import java.io.ObjectInputStream.GetField;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass {
	
		public static void main(String[] args){
			PayrollServicesImpl payrollServices = new PayrollServicesImpl();
			int associateId = payrollServices.acceptAssociateDetails("Aishwarya", "Patil", "aishu@abc.com", "Java", "Analyst", "avbc1235", 50000f, 25000f, 6000f, 6000f, 123456789, "Citi", "citi005");
			 System.out.println(associateId);
			 System.out.println(payrollServices.getAssociateDetails(associateId).getFirstName());
			 System.out.println(payrollServices.getAssociateDetails(associateId).getLastName());
			 
			 System.out.println(payrollServices.calculateNetSalary(associateId));	
			 System.out.println(payrollServices.getAssociateDetails(associateId).getSalary().getHra());
			 System.out.println(payrollServices.getAssociateDetails(associateId).getSalary().getConveyenceAllowance());
			 System.out.println(payrollServices.getAssociateDetails(associateId).getSalary().getOtherAllowance());
			 System.out.println(payrollServices.getAssociateDetails(associateId).getSalary().getPersonalAllowance());
			 System.out.println(payrollServices.getAssociateDetails(associateId).getSalary().getGrossSalary());
			 System.out.println(payrollServices.getAssociateDetails(associateId).getSalary().getMonthlyTax());
			 
			 
			}
}
	
	
	


