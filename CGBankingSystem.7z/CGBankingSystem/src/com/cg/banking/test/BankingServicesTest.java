package com.cg.banking.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServices;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;


public class BankingServicesTest {
	private static BankingServices bankingServices;
	@BeforeClass
	public static void setUpTestEvn(){
		bankingServices=new BankingServicesImpl();
	}
	@Before
	public void setUpMockData(){
		
		
			Customer customer1 = new Customer(BankingDAOServicesImpl.CUSTOMER_ID_COUNTER++, "alamel", "mangai", "chinnu@gmail.com", "SDFG344", new Address(600045, "Chennai","TN"), new Address(600055, "Chennai", "Tn"));
			Account account1 = new Account(1234, 0, "savings", "active", 1000, BankingDAOServicesImpl.ACCOUNTNO_COUNTER++);
			Transaction transaction1 = new Transaction(1, 2000, "withdrawal");
			BankingDAOServicesImpl.customers.put(customer1.getCustomerId(),customer1);
			BankingDAOServicesImpl.customers.get(customer1.getCustomerId()).getAccounts().put(account1.getAccountNo(),account1);
			BankingDAOServicesImpl.customers.get(customer1.getCustomerId()).getAccounts().get(account1.getAccountNo()).getTransactions().put(transaction1.getTransactionId(), transaction1);
			Customer customer2 = new Customer(BankingDAOServicesImpl.CUSTOMER_ID_COUNTER++, "deepak", "muraree", "deepakproo@gmail.com", "DFHR555", new Address(600033, "Kolkata","WB"), new Address(600033, "Kolkata","WB"));
			Account account2 = new Account(1245, 0, "savings", "Inactive", 2000, BankingDAOServicesImpl.ACCOUNTNO_COUNTER++);
			Transaction transaction2 = new Transaction(1, 3000, "deposit");
			BankingDAOServicesImpl.customers.put(customer2.getCustomerId(),customer2);
			BankingDAOServicesImpl.customers.get(customer2.getCustomerId()).getAccounts().put(account2.getAccountNo(),account2);
			BankingDAOServicesImpl.customers.get(customer2.getCustomerId()).getAccounts().get(account2.getAccountNo()).getTransactions().put(transaction2.getTransactionId(), transaction2);
			
		}

		/*@Test

		public void testGetCustomerDetails() {
			Customer actualCustomer = BankingDAOServicesImpl.customers.get(001);
			Customer expectedCustomer = new Customer(001, "aishu", "patil", "aishu@abc.com", "abcd1234", new Address(590006, "Bgm", "Kar"), new Address(560009, "DWR", "Kar"));
			assertEquals(actualCustomer, expectedCustomer);
		}*/
		@Test
		public void testAcceptCustomerDetails() throws BankingServicesDownException{
			int actualCustomerId = bankingServices.acceptCustomerDetails("akarsh", "patil", "aka@abc.com", "nbhk1456", "bgm", "Kar", 590006, "dwr", "Kar", 560009);
			assertEquals(102, actualCustomerId);
		}
		@Test
		public void testToOpenAccountValidData() throws CustomerNotFoundException, BankingServicesDownException{
			bankingServices.getCustomerDetails(100);
		}
		
		@Test(expected=CustomerNotFoundException.class)
		public void testOpenAccountForInvalidCustomer() throws CustomerNotFoundException, InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException{
			bankingServices.openAccount(123, "savings", 1000);
		
		}
		@Test(expected=InvalidAccountTypeException.class)
		public void testOpenAccountForInvalidAccountType() throws CustomerNotFoundException, InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException{
			assertEquals(11112222,bankingServices.openAccount(100, "asdfkh", 1000));
		}
		@Test(expected=InvalidAmountException.class)
		public void testOpenAccountForInvalidAmount() throws CustomerNotFoundException, InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException{
			assertEquals(11112222, bankingServices.openAccount(100, "savings", -200));
		}
		@Test
		public void testDepostiAmountForValidData() throws CustomerNotFoundException, InvalidAmountException, AccountNotFoundException, AccountBlockedException, BankingServicesDownException{
			assertEquals(1100, bankingServices.depositAmount(100, 11112222, 100), 0);
			
		}
		@Test(expected=CustomerNotFoundException.class)
		public void testDepostiAmountForInvalidCustomer() throws CustomerNotFoundException, InvalidAmountException, AccountNotFoundException, AccountBlockedException, BankingServicesDownException{
			assertEquals(2000, bankingServices.depositAmount(125, 11112222, 1000), 0);
		}
		@Test(expected=AccountNotFoundException.class)
		public void testDepostiAmountForInvalidAccountNo() throws CustomerNotFoundException, InvalidAmountException, AccountNotFoundException, AccountBlockedException, BankingServicesDownException{
			assertEquals(2000, bankingServices.depositAmount(100, 11112254, 1000), 0);
		}
		@Test(expected=AccountBlockedException.class)
		public void testDepostiAmountForAccountBlocked() throws CustomerNotFoundException, InvalidAmountException, AccountNotFoundException, AccountBlockedException, BankingServicesDownException{
			assertEquals(2000, bankingServices.depositAmount(101, 11112254, 1000), 0);
		}
		
		
		
		@After
		public void tearDownMockData(){
			BankingDAOServicesImpl.customers.clear();
			BankingDAOServicesImpl.CUSTOMER_ID_COUNTER=100;
			BankingDAOServicesImpl.ACCOUNTNO_COUNTER=123456789;
		}
		@AfterClass
		public static void tearDownTestEnv(){
			bankingServices=null;
		}
		
}
		
			
		
		
	
