package com.cg.student.daoservices;

import java.util.List;

import com.cg.student.beans.Student;

public class StudentDAOServiceImpl implements StudentDAOServices{

	@Override
	public int insertStudent(Student student) {
		
		return 0;
	}

	@Override
	public boolean updateAssociate(Student student) {
		
		return false;
	}

	@Override
	public boolean deleteAssociate(int studentId) {
		
		return false;
	}

	@Override
	public Student getStudent(int studentId) {
		
		return null;
	}

	@Override
	public List<Student> getStudent() {
	
		return null;
	}

}
