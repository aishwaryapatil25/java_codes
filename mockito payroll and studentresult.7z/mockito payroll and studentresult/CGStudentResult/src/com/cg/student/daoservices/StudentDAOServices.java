package com.cg.student.daoservices;
import java.util.List;

import com.cg.student.beans.Student;
public interface StudentDAOServices {
	int insertStudent (Student student);
	boolean updateAssociate(Student student);
	boolean deleteAssociate(int studentId);
	Student getStudent(int studentId);
	List<Student> getStudent();
	

}
