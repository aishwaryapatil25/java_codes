package com.cg.payroll.main;

import com.cg.payroll.beans.Associate;

public class MainClass {
	public static void main(String[] args) {
		Associate associate = new Associate(1234, 15000, "Aishwarya", "Patil", "Java", "Associate", "abcd1234", "abc.com");
		System.out.print(associate.getFirstName());
	}
	
	
	}


