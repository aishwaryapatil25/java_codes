package com.cg.payroll.test;
import static org.junit.Assert.*;
import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mockito;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServices;

import com.cg.payroll.exceptions.AssociateDetailsNotFoundExceptions;
import com.cg.payroll.exceptions.PayrollServicesDownExceptions;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class PayrollServicesTest {
	private static PayrollServices payrollServices;
	private static PayrollDAOServices mockDAOServices;
	@BeforeClass
	public static void setUpTestEvn(){
		mockDAOServices = Mockito.mock(PayrollDAOServices.class);
		payrollServices= new PayrollServicesImpl(mockDAOServices);
	}
	@Before
	public void setUpMockData(){
		Associate associate1 = new Associate(new Salary(25000, 1000, 1000), new BankDetails(1234, "Citi", "citi005"), 1000, 150000, "Aishwarya", "Patil", "Java", "Analyst", "abh4854jkh", "aishu@abc.com");
		Associate associate2 = new Associate(new Salary(20000, 1000, 1000), new BankDetails(4781, "HDFC", "hdfc114"), 1001, 15000, "Akarsh", "Patil", "Java", "Analyst", "a465jsjk", "aka@abc.com");
		Associate associate3=new Associate(new Salary(15000, 1000, 1000), new BankDetails(1475, "HDFC", "hdfc005"),  15000, "Apoorva", "PV", "Java", "Analyst", "akjl451", "apu@abc.com");
		
		ArrayList<Associate>associateList=new ArrayList<>();
		associateList.add(associate1);
		associateList.add(associate2);
		Mockito.when(mockDAOServices.getAssociate(1000)).thenReturn(associate1);
		Mockito.when(mockDAOServices.getAssociate(1002)).thenReturn(associate2);
		Mockito.when(mockDAOServices.getAssociate(1001)).thenReturn(associate3);
		Mockito.when(mockDAOServices.getAssociate(1234)).thenReturn(null);
		//Mockito.when(mockDAOServices.getAssociate()).thenReturn(value)
		Mockito.when(mockDAOServices.insertAssociate(associate3)).thenReturn(1003);
		
		
	}
	@After
	public void tearDownData(){
		
	}
	@Test
	public void testToAcceptAssociateId() throws PayrollServicesDownExceptions, AssociateDetailsNotFoundExceptions {
		
		Associate expectedassociate = new Associate(new Salary(25000, 1000, 1000), new BankDetails(1234, "Citi", "citi005"), 1000, 150000, "Aishwarya", "Patil", "Java", "Analyst", "abh4854jkh", "aishu@abc.com");
		Associate actualassociate = payrollServices.getAssociateDetails(1000);
		assertEquals( expectedassociate, actualassociate);
	}
	@Test
	public void testAssociateIdFound() throws AssociateDetailsNotFoundExceptions, PayrollServicesDownExceptions{
		
		
	}
	@Test(expected=AssociateDetailsNotFoundExceptions.class)
	public void testAssociateDetailsNotFound() throws AssociateDetailsNotFoundExceptions, PayrollServicesDownExceptions{
		payrollServices.getAssociateDetails(1234);
		Mockito.verify(mockDAOServices).getAssociate(1234);
		
	}
	@Test
	public void testAssociateDetailsFound() throws AssociateDetailsNotFoundExceptions, PayrollServicesDownExceptions{
		
	}
	@Test
	public void testNetSalary() throws AssociateDetailsNotFoundExceptions, PayrollServicesDownExceptions {
		
	}
	@Test
	public void testDeleteValidAssociateId() throws PayrollServicesDownExceptions, AssociateDetailsNotFoundExceptions{
		
	}
	@Test(expected=AssociateDetailsNotFoundExceptions.class)
	public void testDeleteInvalidAssociateId() throws PayrollServicesDownExceptions, AssociateDetailsNotFoundExceptions{
		payrollServices.deleteAssociate(1001);
		Mockito.verify(mockDAOServices).deleteAssociate(1001);
	}
	@Test
	public void testGetAllAssociateDetails(){
		
	}
	@AfterClass
	public static void tearDownSetEnv(){
		
	}
}

