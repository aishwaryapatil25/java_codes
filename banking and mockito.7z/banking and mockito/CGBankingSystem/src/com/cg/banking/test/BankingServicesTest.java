package com.cg.banking.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServices;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;


public class BankingServicesTest {
	private static BankingServices bankingServices;
	@BeforeClass
	public static void setUpTestEvn(){
		bankingServices=new BankingServicesImpl();
	}
	@Before
	public void setUpMockData(){

		BankingDAOServicesImpl.CUSTOMER_ID_COUNTER=111;
		BankingDAOServicesImpl.ACCOUNTNO_COUNTER=11112222;
		Customer customer1 = new Customer(BankingDAOServicesImpl.CUSTOMER_ID_COUNTER, "aishu", "p", "aishu@gmail.com", "abcd1234", 
				new Address(590006, "Bgm","Kar"), 
				new Address(590006, "Bgm","Kar"));
		Account account1 = new Account(1234, 0, "savings", "active", 1000, BankingDAOServicesImpl.ACCOUNTNO_COUNTER);
		Transaction transaction1 = new Transaction(1, 2000, "withdrawal");
		BankingDAOServicesImpl.customers.put(BankingDAOServicesImpl.CUSTOMER_ID_COUNTER,customer1);
		BankingDAOServicesImpl.customers.get(BankingDAOServicesImpl.CUSTOMER_ID_COUNTER).getAccounts().put(BankingDAOServicesImpl.ACCOUNTNO_COUNTER,account1);
		BankingDAOServicesImpl.customers.get(BankingDAOServicesImpl.CUSTOMER_ID_COUNTER++).getAccounts().get(BankingDAOServicesImpl.ACCOUNTNO_COUNTER++).getTransactions().put(transaction1.getTransactionId(), transaction1);

		Customer customer2 = new Customer(BankingDAOServicesImpl.CUSTOMER_ID_COUNTER, "akarsh", "p", "akarsh@gmail.com", "acdc1234", 
				new Address(590006, "Bgm","Kar"), 
				new Address(590006, "Bgm","Kar"));
		Account account2 = new Account(4321, 0, "savings", "active", 1000, BankingDAOServicesImpl.ACCOUNTNO_COUNTER);
		Transaction transaction2 = new Transaction(1, 2000, "withdrawal");
		BankingDAOServicesImpl.customers.put(BankingDAOServicesImpl.CUSTOMER_ID_COUNTER,customer1);
		BankingDAOServicesImpl.customers.get(BankingDAOServicesImpl.CUSTOMER_ID_COUNTER).getAccounts().put(BankingDAOServicesImpl.ACCOUNTNO_COUNTER,account1);
		BankingDAOServicesImpl.customers.get(BankingDAOServicesImpl.CUSTOMER_ID_COUNTER++).getAccounts().get(BankingDAOServicesImpl.ACCOUNTNO_COUNTER++).getTransactions().put(transaction1.getTransactionId(), transaction1);

	}

	/*@Test

		public void testGetCustomerDetails() {
			Customer actualCustomer = BankingDAOServicesImpl.customers.get(001);
			Customer expectedCustomer = new Customer(001, "aishu", "patil", "aishu@abc.com", "abcd1234", new Address(590006, "Bgm", "Kar"), new Address(560009, "DWR", "Kar"));
			assertEquals(actualCustomer, expectedCustomer);
		}*/
	@Test
	public void testAcceptCustomerDetails() throws BankingServicesDownException{
		int actualCustomerId = bankingServices.acceptCustomerDetails("akarsh", "patil", "aka@abc.com", "nbhk1456", "bgm", "Kar", 590006, "dwr", "Kar", 560009);
		assertEquals(113, actualCustomerId);
	}
	@Test
	public void testToOpenAccountValidData() throws CustomerNotFoundException, BankingServicesDownException{
		bankingServices.getCustomerDetails(111);
	}
	/*@Test
	public void testToOpenAccountValidData1() throws CustomerNotFoundException, BankingServicesDownException{
		bankingServices.getCustomerDetails(112);
	}*/


	@Test(expected=CustomerNotFoundException.class)
	public void testOpenAccountForInvalidCustomer() throws CustomerNotFoundException, InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException{
		bankingServices.openAccount(123, "savings", 1000);

	}
	@Test(expected=InvalidAccountTypeException.class)
	public void testOpenAccountForInvalidAccountType() throws CustomerNotFoundException, InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException{
		assertEquals(11112222,bankingServices.openAccount(111, "asdfkh", 1000));
	}
	@Test(expected=InvalidAmountException.class)
	public void testOpenAccountForInvalidAmount() throws CustomerNotFoundException, InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException{
		assertEquals(11112222, bankingServices.openAccount(111, "savings", -200));
	}
	@Test
	public void testDepostiAmountForValidData() throws CustomerNotFoundException, InvalidAmountException, AccountNotFoundException, AccountBlockedException, BankingServicesDownException{
		assertEquals(1100, bankingServices.depositAmount(112, 11112222, 100), 0);

	}
	@Test(expected=CustomerNotFoundException.class)
	public void testDepostiAmountForInvalidCustomer() throws CustomerNotFoundException, InvalidAmountException, AccountNotFoundException, AccountBlockedException, BankingServicesDownException{
		assertEquals(2000, bankingServices.depositAmount(125, 11112222, 1000), 0);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testDepostiAmountForInvalidAccountNo() throws CustomerNotFoundException, InvalidAmountException, AccountNotFoundException, AccountBlockedException, BankingServicesDownException{
		assertEquals(2000, bankingServices.depositAmount(111, 11112254, 1000), 0);
	}
	@Test(expected=AccountBlockedException.class)
	public void testDepostiAmountForAccountBlocked() throws CustomerNotFoundException, InvalidAmountException, AccountNotFoundException, AccountBlockedException, BankingServicesDownException{
		bankingServices.getAccountDetails(112, 11112222).setStatus("Inactive");
		assertEquals(2000, bankingServices.depositAmount(112, 11112222, 1000), 0);
	}
	@Test
	public void testShowBalanceForValidData() throws CustomerNotFoundException, InvalidAmountException, AccountNotFoundException, AccountBlockedException, BankingServicesDownException{
	assertEquals(2000, bankingServices.depositAmount(111, 11112222, 1000), 0);
	}
	@Test(expected=CustomerNotFoundException.class)
	public void testShowBalanceForInvalidCustomer() throws CustomerNotFoundException, AccountNotFoundException, AccountBlockedException, InvalidPinNumberException, BankingServicesDownException{
		assertEquals(1000, bankingServices.showBalance(124, 11112222, 1234),0);
	}
	@Test(expected=AccountNotFoundException.class)
	public void testShowBalanceForInvalidAccount() throws CustomerNotFoundException, AccountNotFoundException, AccountBlockedException, InvalidPinNumberException, BankingServicesDownException{
		assertEquals(1000, bankingServices.showBalance(111, 11111243, 1234),0);
	}
	@Test(expected=AccountBlockedException.class)
	public void testShowBalanceForBlockedAccount() throws CustomerNotFoundException, AccountNotFoundException, AccountBlockedException, InvalidPinNumberException, BankingServicesDownException{
		bankingServices.getAccountDetails(112, 11112222).setStatus("blocked");
		assertEquals(1000, bankingServices.showBalance(112, 11112222, 4321),0);
	}
	@Test(expected=InvalidPinNumberException.class)
	public void testShowBalanceForInvalidPin() throws CustomerNotFoundException, AccountNotFoundException, AccountBlockedException, InvalidPinNumberException, BankingServicesDownException{
		assertEquals(1000, bankingServices.showBalance(112, 11112222, 7895),0);
	}
	
	
	


	@After
	public void tearDownMockData(){
		BankingDAOServicesImpl.customers.clear();
		BankingDAOServicesImpl.CUSTOMER_ID_COUNTER=111;
		BankingDAOServicesImpl.ACCOUNTNO_COUNTER=11112222;
	}
	@AfterClass
	public static void tearDownTestEnv(){
		bankingServices=null;
	}

}





