package com.cg.payroll.main;
import java.io.ObjectInputStream.GetField;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.*;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.exceptions.PayrollServicesDownException;

public class MainClass {

	public static void main(String[] args) {
		try{
		PayrollServicesImpl payrollServices = new PayrollServicesImpl();

		
		int associateId1=payrollServices.acceptAssociateDetails("aishu", "patil", "aishu@abc.com", "java", "analyst", "abcd1245", 20000, 16000, 6000, 6000, 1245637, "citi", "citi005");
		System.out.println(associateId1);
		int associateId2=payrollServices.acceptAssociateDetails("aishu", "patil", "aishu@abc.com", "java", "analyst", "abcd1245", 20000, 16000, 6000, 6000, 1245637, "citi", "citi005");
		System.out.println(associateId2);
		int associateId3=payrollServices.acceptAssociateDetails("aishu", "patil", "aishu@abc.com", "java", "analyst", "abcd1245", 20000, 16000, 6000, 6000, 1245637, "citi", "citi005");
		System.out.println(associateId3);
		int associateId4=payrollServices.acceptAssociateDetails("akarsh", "patil", "aishu@abc.com", "java", "analyst", "abcd1245", 20000, 16000, 6000, 6000, 1245637, "citi", "citi005");
		System.out.println(associateId4);
		int associateId5=payrollServices.acceptAssociateDetails("akarsh", "patil", "aishu@abc.com", "java", "analyst", "abcd1245", 20000, 16000, 6000, 6000, 1245637, "citi", "citi005");
		System.out.println(associateId5);
		int associateId6=payrollServices.acceptAssociateDetails("aishu", "patil", "aishu@abc.com", "java", "analyst", "abcd1245", 20000, 16000, 6000, 6000, 1245637, "citi", "citi005");
		System.out.println(associateId6);
		int associateId7=payrollServices.acceptAssociateDetails("aishu", "patil", "aishu@abc.com", "java", "analyst", "abcd1245", 20000, 16000, 6000, 6000, 1245637, "citi", "citi005");
		System.out.println(associateId7);
		int associateId8=payrollServices.acceptAssociateDetails("akarsh", "patil", "aishu@abc.com", "java", "analyst", "abcd1245", 20000, 16000, 6000, 6000, 1245637, "citi", "citi005");
		System.out.println(associateId8);
		int associateId9=payrollServices.acceptAssociateDetails("aishu", "patil", "aishu@abc.com", "java", "analyst", "abcd1245", 20000, 16000, 6000, 6000, 1245637, "citi", "citi005");
		System.out.println(associateId9);
		int associateId10=payrollServices.acceptAssociateDetails("akarsh", "patil", "aishu@abc.com", "java", "analyst", "abcd1245", 20000, 16000, 6000, 6000, 1245637, "citi", "citi005");
		System.out.println(associateId10);
		int associateId11=payrollServices.acceptAssociateDetails("aishu", "patil", "aishu@abc.com", "java", "analyst", "abcd1245", 20000, 16000, 6000, 6000, 1245637, "citi", "citi005");
		System.out.println(associateId11);
		payrollServices.calculateNetSalary(associateId1);

		System.out.println(payrollServices.calculateNetSalary(associateId1));
		System.out.println(payrollServices.getAssociateDetails(associateId11));
		}catch (AssociateDetailsNotFoundExceptions e){
			e.printStackTrace();
		}
		catch(PayrollServicesDownException e){
			e.printStackTrace();
		}
	}		
		
}		
		





