package com.cg.payroll.test;
import static org.junit.Assert.*;
import java.util.ArrayList;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundExceptions;
import com.cg.payroll.exceptions.PayrollServicesDownExceptions;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class PayrollServicesTest {
	private static PayrollServices payrollServices;
	@BeforeClass
	public static void setUpTestEvn(){
		payrollServices=new PayrollServicesImpl();
	}
	@Before
	public void setUpMockData(){
		PayrollDAOServicesImpl.ASSOCIATE_ID_COUNTER=111;
		Associate associate1 = new Associate(new Salary(20000, 1000, 1000), new BankDetails(1234, "Citi", "citi005"), PayrollDAOServicesImpl.ASSOCIATE_ID_COUNTER++, 150000, "Aishwarya", "Patil", "Java", "Analyst", "abh4854jkh", "aishu@abc.com");
		Associate associate2 = new Associate(new Salary(20000, 1000, 1000), new BankDetails(4781, "HDFC", "hdfc114"), PayrollDAOServicesImpl.ASSOCIATE_ID_COUNTER++, 15000, "Akarsh", "Patil", "Java", "Analyst", "a465jsjk", "aka@abc.com");
		Associate associate3 = new Associate(new Salary(25000, 1000, 1000), new BankDetails(7423, "SBI", "004sbi"), PayrollDAOServicesImpl.ASSOCIATE_ID_COUNTER++, 15000, "Apoorva", "PV", "Java", "Analyst", "ojk435lm", "apu@abc.com");	
		PayrollDAOServicesImpl.associates.put(associate1.getAssociateID(), associate1);
		PayrollDAOServicesImpl.associates.put(associate2.getAssociateID(), associate2);
		PayrollDAOServicesImpl.associates.put(associate3.getAssociateID(), associate3);
	}
	@After
	public void tearDownData(){
		PayrollDAOServicesImpl.associates.clear();
		PayrollDAOServicesImpl.ASSOCIATE_ID_COUNTER=111;
	}
	@Test
	public void testToAcceptAssociateId() throws PayrollServicesDownExceptions, AssociateDetailsNotFoundExceptions {
		int actualAssociateId=payrollServices.acceptAssociateDetails("Aishwarya", "PAtil", "Java", "Analyst", "124khsh", "aishu@abc.com", 150000, 20000, 1000, 1000, 1243, "Citi", "citi005");
		assertEquals(114, actualAssociateId);
	}
	@Test
	public void testAssociateIdFound() throws AssociateDetailsNotFoundExceptions, PayrollServicesDownExceptions{
		payrollServices.getAssociateDetails(111);
	}
	@Test(expected=AssociateDetailsNotFoundExceptions.class)
	public void testAssociateDetailsNotFound() throws AssociateDetailsNotFoundExceptions, PayrollServicesDownExceptions{
		payrollServices.getAssociateDetails(145);
	}
	@Test
	public void testAssociateDetailsFound() throws AssociateDetailsNotFoundExceptions, PayrollServicesDownExceptions{
		Associate expectedAssociate = new Associate(new Salary(20000, 1000, 1000), new BankDetails(1234, "Citi", "citi005"), 111, 150000, "Aishwarya", "Patil", "Java", "Analyst", "abh4854jkh", "aishu@abc.com");
		assertEquals(expectedAssociate, payrollServices.getAssociateDetails(111));
	}
	@Test
	public void testNetSalary() throws AssociateDetailsNotFoundExceptions, PayrollServicesDownExceptions {
		double actualNetSalary = payrollServices.calculateNetSalary(111);
		assertEquals(35533.33f, actualNetSalary,33);
	}
	@Test
	public void testDeleteValidAssociateId() throws PayrollServicesDownExceptions, AssociateDetailsNotFoundExceptions{
		Assert.assertTrue(payrollServices.deleteAssociate(111));
	}
	@Test(expected=AssociateDetailsNotFoundExceptions.class)
	public void testDeleteInvalidAssociateId() throws PayrollServicesDownExceptions, AssociateDetailsNotFoundExceptions{
		Assert.assertTrue(payrollServices.deleteAssociate(1213));
	}
	@Test
	public void testGetAllAssociateDetails(){
		ArrayList<Associate>associate = new ArrayList<>(PayrollDAOServicesImpl.associates.values());
		assertEquals(associate.size(), PayrollDAOServicesImpl.ASSOCIATE_ID_COUNTER-111);
	}
	@AfterClass
	public static void tearDownSetEnv(){
		payrollServices=null;
	}
}

