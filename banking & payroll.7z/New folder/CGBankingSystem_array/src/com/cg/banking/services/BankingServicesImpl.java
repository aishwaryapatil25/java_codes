package com.cg.banking.services;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServices;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.exceptions.*;

public class BankingServicesImpl implements BankingServices{
	private BankingDAOServices daoSevicesImpl;
	public  BankingServicesImpl() {
		daoSevicesImpl = new BankingDAOServicesImpl();
	}

	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String customerEmailId, String panCard,
			String localAddressCity, String localAddressState, int localAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode) {
		return daoSevicesImpl.insertCustomer(new Customer(firstName, lastName, customerEmailId, panCard, new Address(localAddressPinCode,  localAddressCity,localAddressState),
				new Address(homeAddressPinCode, homeAddressCity, homeAddressState)));
	}

	@Override
	public long openAccount(int customerId, String accountType, float initBalance) {
		

		return daoSevicesImpl.insertAccount(customerId, new Account(accountType, initBalance));
	}

	@Override
	public float depositAmount(int customerId, long accountNo, float amount) {
		daoSevicesImpl.insertTransaction(customerId, accountNo, new Transaction(amount));
		this.getAccountDetails(customerId, accountNo).setAccountBalance(getAccountDetails(customerId, accountNo).getAccountBalance()+amount);
		getAccountDetails(customerId, accountNo).setStatus("Active");
		return this.getAccountDetails(customerId, accountNo).getAccountBalance();
		}

	@Override
	public float withdrawAmount(int customerId, long accountNo, float amount, int pinNumber) {
		while(getAccountDetails(customerId, accountNo)!=null&&getAccountDetails(customerId, accountNo).getPinCounter()<3){
			if(pinNumber==getAccountDetails(customerId, accountNo).getPinNumber()) {
				if(amount<=daoSevicesImpl.getAccount(customerId, accountNo).getAccountBalance()) {
					daoSevicesImpl.insertTransaction(customerId, accountNo, new Transaction(amount));
					float totalBalance=this.getAccountDetails(customerId, accountNo).getAccountBalance()-amount;
					this.getAccountDetails(customerId, accountNo).setAccountBalance(totalBalance);
					getAccountDetails(customerId, accountNo).setPinCounter(0);
					return this.getAccountDetails(customerId, accountNo).getAccountBalance();
				}
				getAccountDetails(customerId, accountNo).setPinCounter(getAccountDetails(customerId, accountNo).getPinCounter()+1);
			}
			else if(getAccountDetails(customerId, accountNo).getPinCounter()>=3) {
				getAccountDetails(customerId, accountNo).setStatus("Blocked");
				return -1;
			}
			else
				return 0;
		}
		return 0;
	}
	@Override
	public boolean fundTransfer(int customerIdTo, long accountNoTo, int customerIdFrom, long accountNoFrom,
			float transferAmount, int pinNumber) {
		if(pinNumber==daoSevicesImpl.getAccount(customerIdFrom, accountNoFrom).getPinNumber())
			if(transferAmount<daoSevicesImpl.getAccount(customerIdFrom, accountNoFrom).getAccountBalance()){
				float totalBalanceTo=(daoSevicesImpl.getAccount(customerIdTo, accountNoTo).getAccountBalance()+transferAmount);
				daoSevicesImpl.getAccount(customerIdTo, accountNoTo).setAccountBalance(totalBalanceTo);
				float totalBalanceFrom=(daoSevicesImpl.getAccount(customerIdFrom, accountNoFrom).getAccountBalance()-transferAmount);
				daoSevicesImpl.getAccount(customerIdFrom, accountNoFrom).setAccountBalance(totalBalanceFrom);
				return true;
			}

		return false;
	}

	@Override
	public Customer getCustomerDetails(int customerId) {
		return 	daoSevicesImpl.getCustomer(customerId);

			}

	@Override
	public Account getAccountDetails(int customerId, long accountNo) {

		return daoSevicesImpl.getAccount(customerId, accountNo);
	}

	@Override
	public int generateNewPin(int customerId, long accountNo) {
		return daoSevicesImpl.generatePin(customerId, account);
	}

	@Override
	public boolean changeAccountPin(int customerId, long accountNo, int oldPinNumber, int newPinNumber) {
		if(oldPinNumber==daoSevicesImpl.getAccount(customerId, accountNo).getPinNumber()){
			oldPinNumber=newPinNumber;
			daoSevicesImpl.getAccount(customerId, accountNo).setPinNumber(oldPinNumber);
			return true;
			
		}

		return false;
	}

	@Override
	public Customer[] getAllCustomerDetails() {

		return daoSevicesImpl.getCustomers();
	}

	@Override
	public Account[] getcustomerAllAccountDetails(int customerId) {

		return daoSevicesImpl.getAccounts(customerId);
	}

	@Override
	public Transaction[] getAccountAllTransaction(int customerId, long accountNo) {

		return daoSevicesImpl.getTransactions(customerId, accountNo);
	}

	@Override
	public String accountStatus(int customerId, long accountNo) {

		return daoSevicesImpl.getAccount(customerId, accountNo).getStatus();
	} 
	@Override
	public boolean closeAccount(int customerId, long accountNo) {
		if(daoSevicesImpl.getAccount(customerId, accountNo).getAccountBalance()==0) {
			daoSevicesImpl.deleteAccount(customerId, accountNo);
			return true;
		}
		return false;
	}

	@Override
	public float showBalance(int customerId, long accountNo, int pinNumber)  {
		return daoSevicesImpl.getAccount(customerId, accountNo).getAccountBalance();
	}

}



