package com.cg.banking.daoservices;

import java.util.Arrays;
import java.util.Random;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;

public class BankingDAOServicesImpl implements BankingDAOServices{

	private static int CUSTOMER_ID_COUNTER=111;
	private static int CUSTOMER_IDX_COUNTER=0;
	private static Customer[] customerList=new Customer[10];
	private static Account[] accountList=new Account[10];
	private static int ACCOUNT_ID_COUNTER=1;
	Random randomgen = new Random();
	private  int pinNumber=randomgen.nextInt(9999) + 1000;

	@Override
	public int insertCustomer(Customer customer) {
		if(CUSTOMER_IDX_COUNTER>70*customerList.length/100){
			Customer[] tempList;
			tempList=Arrays.copyOf(customerList, 10+customerList.length);
			customerList=tempList;

		}
		customer.setCustomerID(CUSTOMER_ID_COUNTER++);
		customerList[CUSTOMER_IDX_COUNTER++]=customer;
		return customer.getCustomerID();
	}
	@Override
	public long insertAccount(int customerId, Account account) {

		for(int i=0;i<customerList.length;i++)
			if(customerList!=null && customerList[i].getCustomerID()==customerId){
				if(customerList[i].getAccountIdxCounter()>70*customerList[i].getAccounts().length/100){
					Account[] templist;
					templist=Arrays.copyOf(customerList[i].getAccounts(), 10+customerList[i].getAccounts().length);
					customerList[i].setAccounts(templist);
				}
					customerList[i].getAccounts()[(int) customerList[i].getAccountIdxCounter()]=account;
					account.setAccountNo(ACCOUNT_ID_COUNTER);
					customerList[i].setAccountIdxCounter(customerList[i].getAccountIdxCounter()+1);
					return account.getAccountNo();
				
			}			

		return 0;
	}
	@Override
	public boolean updateAccount(int customerId, Account account) {
		for(int i=0;i<customerList.length;i++){
			for(int j=0;j<customerList[i].getAccounts().length;j++){
				if(customerList[i]!=null && customerList[i].getCustomerID()==customerId && 
						customerList[i].getAccounts()[j]!=null && 
						customerList[i].getAccounts()[j].getAccountNo()==account.getAccountNo())
					customerList[i].getAccounts()[j]=account;
				return true;


			}
		}

		return false;
	}
	@Override
	public int generatePin(int customerId, Account account) {
		for(int i=0;i<customerList.length;i++){
			for(int j=0;j<customerList[i].getAccounts().length;j++){
				if(customerList[i]!=null && customerList[i].getCustomerID()==customerId && 
						customerList[i].getAccounts()[j]!=null && 
						customerList[i].getAccounts()[j].getAccountNo()==account.getAccountNo())
					customerList[i].getAccounts()[j].setPinNumber(pinNumber);

			}
		}

		return 0;
	}
	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		for(int i=0;i<customerList.length;i++){
			for(int j=0;j<customerList[i].getAccounts().length;j++){
				if(customerList[i]!=null && customerList[i].getCustomerID()==customerId && 
						customerList[i].getAccounts()[j]!=null && 
						customerList[i].getAccounts()[j].getAccountNo()==accountNo)
					
				transaction.setTransactionId(getAccount(customerId, accountNo).getTransactionIdCounter());
				getAccount(customerId, accountNo).setTransactionIdCounter(getAccount(customerId, accountNo).getTransactionIdCounter()+1);
				getAccount(customerId, accountNo).getTransactions()[getAccount(customerId, accountNo).getTransactionIdxCounter()]=transaction;
				getAccount(customerId, accountNo).setTransactionIdCounter(getAccount(customerId, accountNo).getTransactionIdCounter()+1);
				
				
				return true;
			}
		}
		return false;
	}
	@Override
	public boolean deleteCustomer(int customerId) {
		for(int i=0;i<customerList.length;i++){
			if(customerList[i]!=null && customerList[i].getCustomerID()==customerId)
				customerList[i]=null;
			return true;
		}
		return false;
	}
	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		for(int i=0;i<customerList.length;i++){
			for(int j=0;j<customerList[i].getAccounts().length;j++){
				if(customerList[i]!=null && customerList[i].getCustomerID()==customerId &&
						customerList[i].getAccounts()[j]!=null && 
						customerList[i].getAccounts()[j].getAccountNo()==accountNo)
					customerList[i].getAccounts()[j]=null;
				return true;
			}

		}

		return false;
	}
	@Override
	public Customer getCustomer(int customerId) {
		for(int i=0;i<customerList.length;i++){
			if(customerList[i]!=null && customerList[i].getCustomerID()==customerId)

				return customerList[i];
		}
		return null;
	}
	@Override
	public Account getAccount(int customerId, long accountNo) {
		for(int i=0;i<customerList.length;i++){
			for(int j=0;j<customerList[i].getAccounts().length;j++){
				if(customerList[i]!=null && customerList[i].getCustomerID()==customerId &&
						customerList[i].getAccounts()[j]!=null && 
						customerList[i].getAccounts()[j].getAccountNo()==accountNo)
					return customerList[i].getAccounts()[j];
			}
		}
		return null;
	}
	@Override
	public Customer[] getCustomers() {
		for(int i=0;i<customerList.length;i++)
			if(customerList[i]!=null)
				return customerList;

		return null;
	}
	@Override
	public Account[] getAccounts(int customerId) {
		for(int i=0;i<customerList.length;i++)
			for(int j=0;j<customerList[i].getAccounts().length;j++)
				if(customerList[i]!=null && customerList[i].getCustomerID()==customerId)
					return customerList[i].getAccounts();


		return null;
	}
	@Override
	public Transaction[] getTransactions(int customerId, long accountNo) {
		for(int i=0;i<customerList.length;i++){
			for(int j=0;j<customerList[i].getAccounts().length;j++){
				if(customerList[i]!=null && customerList[i].getCustomerID()==customerId
						&& customerList[i].getAccounts()[j].getAccountNo()==accountNo){
					return customerList[i].getAccounts()[j].getTransactions();

				}
			}
		}

		return null;
	}
	



}
