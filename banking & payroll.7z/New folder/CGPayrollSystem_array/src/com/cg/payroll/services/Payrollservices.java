package com.cg.payroll.services;
import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.*;

public interface Payrollservices {

	int acceptAssociateDetails(String firstName, String lastName, String emailId, String department, String designation,
			String pancard, double yearlyInvestmentUnder80C, double basicSalary, double epf, double companyPf,
			int accountNumber, String bankName, String ifscCode) throws PayrollServicesDownException;

	double calculateNetSalary(int associateId) throws AssociateDetailsNotFoundExceptions,PayrollServicesDownException;

	Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundExceptions,PayrollServicesDownException;

	Associate[] getAllAssociatesDetails() throws PayrollServicesDownException;

	boolean updateAssociate(Associate associate) throws PayrollServicesDownException;
	boolean deleteAssociate(int associateId) throws PayrollServicesDownException;

}