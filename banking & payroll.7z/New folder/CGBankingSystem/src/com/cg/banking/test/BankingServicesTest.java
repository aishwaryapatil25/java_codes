package com.cg.banking.test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.daoservices.BankingDAOServices;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;


public class BankingServicesTest {
	private static BankingServices bankingServices;
	@BeforeClass
	public static void setUpTestEvn(){
		bankingServices=new BankingServicesImpl();
	}
	@Before
	public void setUpMockData(){
		BankingDAOServicesImpl.CUSTOMER_ID_COUNTER=111;
		
	}
}
