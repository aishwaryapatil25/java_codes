package com.cg.banking.services;

import java.awt.image.BandedSampleModel;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.CustomerNotFoundException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;

public interface BankingServices {

	int acceptCustomerDetails(String firstName,String lastName,String customerEmailId,String panCard,String localAddressCity,
			String localAddressState,int localAddressPinCode,String homeAddressCity,
			String homeAddressState,int homeAddressPinCode) throws BankingServicesDownException;



	long openAccount(int customerId,String accountType,float initBalance) 
			throws CustomerNotFoundException,
			InvalidAmountException,
			InvalidAccountTypeException,
			BankingServicesDownException;
			
	float depositAmount(int customerId,long accountNo,float amount)
	throws CustomerNotFoundException,InvalidAmountException,
	AccountNotFoundException,AccountBlockedException,BankingServicesDownException;
	
			

	float showBalance(int customerId,long accountNo,int pinNumber)
	throws CustomerNotFoundException,AccountNotFoundException,
	AccountBlockedException,InvalidPinNumberException,
	BankingServicesDownException;
		
	float withdrawAmount(int customerId,long accountNo,float amount,int pinNumber)
	throws CustomerNotFoundException,AccountNotFoundException,InvalidAmountException,
	InsufficientAmountException,AccountBlockedException,InvalidPinNumberException,BankingServicesDownException;
			
	boolean fundTransfer(int customerIdTo,long accountNoTo,int customerIdFrom,long accountNoFrom,float transferAmount,int pinNumber)
	throws CustomerNotFoundException,AccountNotFoundException,InvalidAmountException,
	InvalidPinNumberException,AccountBlockedException,BankingServicesDownException,
	InsufficientAmountException;
	
	Customer getCustomerDetails(int customerId)
	throws CustomerNotFoundException,BankingServicesDownException;
	

	Account getAccountDetails(int customerId,long accountNo)
			throws CustomerNotFoundException,AccountNotFoundException,BankingServicesDownException;

	public int generateNewPin(int customerId,long accountNo)
	throws CustomerNotFoundException,AccountNotFoundException,BankingServicesDownException;
			

	public boolean changeAccountPin(int customerId,long accountNo,int oldPinNumber,int newPinNumber)
	throws CustomerNotFoundException,AccountNotFoundException,InvalidPinNumberException,BankingServicesDownException;


	List<Customer> getAllCustomerDetails()
	throws BankingServicesDownException;

	List<Account> getcustomerAllAccountDetails(int customerId)
		throws CustomerNotFoundException,BankingServicesDownException;	

	List<Transaction> getAccountAllTransaction(int customerId,long accountNo) 
	throws CustomerNotFoundException,AccountNotFoundException,BankingServicesDownException;
			
	public String accountStatus(int customerId,long accountNo)
	throws CustomerNotFoundException,AccountNotFoundException,
	AccountBlockedException,BankingServicesDownException;
			

	boolean closeAccount(int customerId, long accountNo)
			throws BankingServicesDownException,
			CustomerNotFoundException,
			AccountNotFoundException;

}