package com.cg.billing.utility;

import java.util.Random;

public class Utility {
	Random randomGen = new Random();
	public long mobileNo= randomGen.nextInt((int) 9999999999l) ;

}
