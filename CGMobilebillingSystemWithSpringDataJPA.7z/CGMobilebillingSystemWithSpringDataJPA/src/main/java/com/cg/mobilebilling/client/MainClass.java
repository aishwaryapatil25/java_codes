package com.cg.mobilebilling.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.mobilebilling.daoservices.DAOServicesBill;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServicesImpl;

public class MainClass {
	public static void main(String[] args) throws BillingServicesDownException, PlanDetailsNotFoundException, CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException, BillDetailsNotFoundException{
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbeans.xml");
		BillingServicesImpl billingServicesImpl = (BillingServicesImpl) applicationContext.getBean("mobileBillingServices");
		billingServicesImpl.createPlan();
		billingServicesImpl.acceptCustomerDetails("aishwarya", "patil", "aishu@gmailcom", "25/11/1994", "Pune","Maharastra", 400162, "Belagavi", "Karnataka", 590006);
		billingServicesImpl.openPostpaidMobileAccount(1, 1);
	//	billingServicesImpl.getMobileBillDetails(1, 01145423214, "jan");
	
	}
	
}