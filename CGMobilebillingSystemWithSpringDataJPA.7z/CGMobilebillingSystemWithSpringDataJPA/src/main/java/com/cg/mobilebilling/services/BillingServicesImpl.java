package com.cg.mobilebilling.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.billing.utility.Utility;
import com.cg.mobilebilling.beans.Address;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.BillingDAOServices;
import com.cg.mobilebilling.daoservices.DAOServicesBill;

import com.cg.mobilebilling.daoservices.DAOServicesCustomer;
import com.cg.mobilebilling.daoservices.DAOServicesPlan;
import com.cg.mobilebilling.daoservices.DAOServicesPostpaid;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
@Component("mobileBillingServices")
public class BillingServicesImpl implements BillingServices {
	@Autowired
	private DAOServicesBill daoServicesBill;
	@Autowired
	private DAOServicesCustomer daoServicesCustomer;
	@Autowired 
	private DAOServicesPlan daoServicesPlan;
	@Autowired 
	private DAOServicesPostpaid daoServicesPostpaid;
	
	PostpaidAccount postpaidAccount;
	
	Customer customer;
	@Override
	public void createPlan() {
		daoServicesPlan.save(new Plan(1, 2500, 20, 20, 100, 100, 500, 2, 4, 1, 2, 500, "Karnataka", "SuperSaver"));
		daoServicesPlan.save(new Plan(2, 2500, 20, 20, 100, 100, 500, 4, 8, 2, 4, 1000, "Karnataka", "MeghaBudget"));
		daoServicesPlan.save(new Plan(3, 2500, 20, 20, 100, 100, 500, 1, 1, 1, 1, 500, "Karnataka", "Basic"));
		
	}
	
	
	
	
	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String emailID, String dateOfBirth,
			String billingAddressCity, String billingAddressState, int billingAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode) throws BillingServicesDownException {
		Customer customer= daoServicesCustomer.save(new Customer(firstName, lastName, emailID, dateOfBirth, new Address(billingAddressPinCode, billingAddressCity, billingAddressState), new Address(homeAddressPinCode, homeAddressCity, homeAddressState)));
		return customer.getCustomerID();
	}

	@Override
	public long openPostpaidMobileAccount(int customerID, int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		if(daoServicesCustomer.findOne(customerID)==null)
			throw new CustomerDetailsNotFoundException("Enter Valid Customer Id");
		Customer customer=daoServicesCustomer.findOne(customerID);
		Plan plan=daoServicesPlan.findOne(planID);
		
		PostpaidAccount postpaidAccount = new PostpaidAccount(plan);
	
	//	postpaidAccount.setMobileNo(Utility);
		postpaidAccount.setCustomer(customer);
		PostpaidAccount postpaidAccount2=daoServicesPostpaid.save(postpaidAccount);
		return 0;
	}

	@Override
	public int generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillingServicesDownException, PlanDetailsNotFoundException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Customer getCustomerDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		if(daoServicesCustomer.findOne(customerID)==null)
			throw new CustomerDetailsNotFoundException();
		return daoServicesCustomer.findOne(customerID);
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws BillingServicesDownException {
		
		return daoServicesCustomer.findAll();
	}
	@Override
	public List<Plan> getPlanAllDetails() throws BillingServicesDownException {
		
		return null;
	}


	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		if(daoServicesCustomer.findOne(customerID)==null)
			throw new CustomerDetailsNotFoundException();
	if(	 customer == daoServicesCustomer.findOne(customerID))
		return daoServicesPostpaid.findOne(mobileNo);
		return null;
	}

	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		customer =daoServicesCustomer.findOne(customerID);
		Map<Long, PostpaidAccount> postpaidaccounts=customer.getPostpaidAccounts();
		List<PostpaidAccount> list= new ArrayList<>(postpaidaccounts.values());
		return list;
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException, BillingServicesDownException {
		if(daoServicesCustomer.findOne(customerID)==null)
			throw new CustomerDetailsNotFoundException();
		if(daoServicesPostpaid.findOne(mobileNo)==null)
			throw new PostpaidAccountNotFoundException();
		if(daoServicesPostpaid.findOne(mobileNo).getBills().get(billMonth)==null)
			throw new InvalidBillMonthException();
		if(daoServicesPostpaid.findOne(mobileNo).getBills()==null)
			throw new BillDetailsNotFoundException();

			if(	 customer== daoServicesCustomer.findOne(customerID) && postpaidAccount==daoServicesPostpaid.findOne(mobileNo))
	//if(customerID==customer.getCustomerID()&&mobileNo==postpaidAccount.getMobileNo())
		return (Bill) daoServicesPostpaid.findOne(mobileNo).getBills();
		return null;
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			BillDetailsNotFoundException {
		if(daoServicesCustomer.findOne(customerID)==null)
			throw new CustomerDetailsNotFoundException();
		if(daoServicesPostpaid.findOne(mobileNo)==null)
			throw new PostpaidAccountNotFoundException();
		if(daoServicesPostpaid.findOne(mobileNo).getBills()==null)
			throw new BillDetailsNotFoundException();
		if(customer==daoServicesCustomer.findOne(customerID) ){
			
			Map<Long, PostpaidAccount> postpaidaccounts=customer.getPostpaidAccounts();
			List<PostpaidAccount> list= new ArrayList<>(postpaidaccounts.values());
			return list;
		}
		return null;
	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID) throws CustomerDetailsNotFoundException,
			PostpaidAccountNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
		
		return false;
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
	
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerID)
			throws BillingServicesDownException, CustomerDetailsNotFoundException {
		
		return false;
	}

	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			PlanDetailsNotFoundException {
		
		return null;
	}

	

}