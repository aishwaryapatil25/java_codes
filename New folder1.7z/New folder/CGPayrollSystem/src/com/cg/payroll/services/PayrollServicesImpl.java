package com.cg.payroll.services;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;

public class PayrollServicesImpl {

	private PayrollDAOServicesImpl daoServicesImpl;

	public PayrollServicesImpl(){
		daoServicesImpl = new PayrollDAOServicesImpl();
	}
	public int acceptAssociateDetails(String firstName,String lastName,String emailId,
			String department,String designation,String pancard,float yearlyInvestmentUnder80C,
			float basicSalary,float epf,float companyPf,int accountNumber,String bankName,String ifscCode){

		Associate associate = new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode));	
		int associateId=daoServicesImpl.insertAssociate(associate);
		return associateId;

	}
	public float calculateNetSalary(int associateId){
		Associate associate =this.getAssociateDetails(associateId);
		if(associate!=null){

			associate.getSalary().setPersonalAllowance((float)0.3*(associate.getSalary().getBasicSalary()));
			associate.getSalary().setConveyenceAllowance((float)0.2*(associate.getSalary().getBasicSalary()));
			associate.getSalary().setOtherAllowance((float)0.1*(associate.getSalary().getBasicSalary()));
			associate.getSalary().setHra((float)0.25*(associate.getSalary().getHra()));
			associate.getSalary().setGratuity((float)0.05*(associate.getSalary().getGratuity()));

			associate.getSalary().setGrossSalary(associate.getSalary().getBasicSalary()+associate.getSalary().getPersonalAllowance()+
					associate.getSalary().getConveyenceAllowance()+associate.getSalary().getOtherAllowance()+
					associate.getSalary().getHra()+associate.getSalary().getCompanyPf());


			return associate.getSalary().getGrossSalary();
		}
		return 0;
	}
	public Associate getAssociateDetails(int associateId){
		return 	daoServicesImpl.getAssociate(associateId);

	}

	public Associate[]getAllAssociatesDetails(){
		return daoServicesImpl.getAssociate();
	}
}
