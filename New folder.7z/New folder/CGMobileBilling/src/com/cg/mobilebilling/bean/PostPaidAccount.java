package com.cg.mobilebilling.bean;

public class PostPaidAccount {
	private long mobileNo;
	private Plan plan;
	private Bill [] bills;
	public PostPaidAccount(){}
	public PostPaidAccount(long mobileNo, Plan plan, Bill[] bills) {
		super();
		this.mobileNo = mobileNo;
		this.plan = plan;
		this.bills = bills;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public Plan getPlan() {
		return plan;
	}
	public void setPlan(Plan plan) {
		this.plan = plan;
	}
	public Bill[] getBills() {
		return bills;
	}
	public void setBills(Bill[] bills) {
		this.bills = bills;
	}
	
	

}
