package com.cg.mobilebilling.bean;

public class Customer {
	private int customerID;
	private long mobileNo,adharNo;
	private String firstName,lastName,emailId,pancardNo,dateOfBirth;
	private Address address;
	private PostPaidAccount [] postPaidAccounts;
	public Customer(){}
	public Customer(int customerID, long mobileNo, long adharNo, String firstName, String lastName, String emailId,
			String pancardNo, String dateOfBirth, Address Address,
			PostPaidAccount[] postPaidAccounts) {
		super();
		this.customerID = customerID;
		this.mobileNo = mobileNo;
		this.adharNo = adharNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.pancardNo = pancardNo;
		this.dateOfBirth = dateOfBirth;
		this.address = Address;
		this.postPaidAccounts = postPaidAccounts;
	}
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public long getAdharNo() {
		return adharNo;
	}
	public void setAdharNo(long adharNo) {
		this.adharNo = adharNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPancardNo() {
		return pancardNo;
	}
	public void setPancardNo(String pancardNo) {
		this.pancardNo = pancardNo;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address billingAddress) {
		this.address = address;
	}
	
	public PostPaidAccount[] getPostPaidAccounts() {
		return postPaidAccounts;
	}
	public void setPostPaidAccounts(PostPaidAccount[] postPaidAccounts) {
		this.postPaidAccounts = postPaidAccounts;
	}
	
}	