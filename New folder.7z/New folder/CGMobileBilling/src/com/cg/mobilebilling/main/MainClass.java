package com.cg.mobilebilling.main;

import com.cg.mobilebilling.bean.Address;
import com.cg.mobilebilling.bean.Bill;
import com.cg.mobilebilling.bean.Customer;
import com.cg.mobilebilling.bean.Plan;
import com.cg.mobilebilling.bean.PostPaidAccount;

public class MainClass {

	public static void main(String[] args) {
		
		
		
		PostPaidAccount []postPaidAccount = new PostPaidAccount[1];
		Plan plan = new Plan(5634, 50, 50, 50, 50, 50, 500, 4569, 8546, 1253, 1245, 5600, "maharastra", "SuperSaver");
		Bill [] bills = new Bill[1];
		bills[0]=new Bill(123, 50, 40, 20, 30, 500, "January", 600.33, 6.00, 6.00, 1500.00, 560.00, 85.00, 852.00);		
		postPaidAccount [0]= new PostPaidAccount(9874563215l, plan, bills);
		
		
		Address address = new Address("Belagavi", "Karnataka", "59006", "India");	
		Customer customer=new Customer(1234, 9874563214l, 1478523697l, "Raj", "M", "raj@abc.com", "AVBH8564", "25/11/94", address, postPaidAccount);
		System.out.println("Customer Name:"+customer.getCustomerID()+" "+customer.getAddress().getCity()+customer.getPostPaidAccounts()[0].getMobileNo()+customer.getPostPaidAccounts()[0].getBills()[0].getBillID()+customer.getPostPaidAccounts()[0].getPlan().getPlanCircle());
		
		
		
	}

}
