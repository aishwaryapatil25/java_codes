package com.cg.banking.beans;
public class Account {
	private int accountNo;;
	private String accountType,accountStatus;
	private float  accountBlance;
	private Transaction [] transactions;
	public Account(){}
	public Account(int accountNo, String accountType, String accountStatus, float accountBlance,
			Transaction[] transactions) {
		super();
		this.accountNo = accountNo;
		this.accountType = accountType;
		this.accountStatus = accountStatus;
		this.accountBlance = accountBlance;
		this.transactions = transactions;
	}
	public int getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}
	public float getAccountBlance() {
		return accountBlance;
	}
	public void setAccountBlance(float accountBlance) {
		this.accountBlance = accountBlance;
	}
	public Transaction[] getTransactions() {
		return transactions;
	}
	public void setTransactions(Transaction[] transactions) {
		this.transactions = transactions;
	}
}	