package com.cg.banking.main;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;

public class MainClass {

	public static void main(String[] args) {
		Transaction transaction[]=new Transaction[1];
		 transaction[0] = new Transaction(1234, 1500, "02-15-30", "Deposit", "Pune", "Cash", "Complete");
		Account account[] = new Account[1];
		 account[0] = new Account(1234, "Deposit", "Complete", 15751.3f, transaction);
		 
		
		
		
		
	}

}
