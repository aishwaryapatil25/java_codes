package com.cg.payroll.main;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass {
	
		public static void main(String[] args){
			PayrollServicesImpl payrollServices = new PayrollServicesImpl();
			
		}
}
	
	
	


