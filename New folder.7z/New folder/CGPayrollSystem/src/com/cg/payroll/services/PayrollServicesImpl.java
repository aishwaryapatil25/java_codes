package com.cg.payroll.services;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;

public class PayrollServicesImpl {
		
	private PayrollDAOServicesImpl daoServicesImpl;
	
	public PayrollServicesImpl(){
		daoServicesImpl = new PayrollDAOServicesImpl();
	}
	public int acceptAssociateDetails(String firstName,String lastName,String emailId,
			String department,String designation,String pancard,int yearlyInvestmentUnder80C,
			int basicSalary,int epf,int companyPf,int accountNo,String bankName,String ifscCode){
		return 0;
		
	}
	public int calculateNetSalary(int associateId){
		return 0;
	}
	public Associate getAssociateDetails(int associateId){
		return null;
	}

	public Associate[]getAllAssociatesDetails(){
		return null;
	}
}
