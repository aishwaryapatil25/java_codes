package com.cg.payroll.daoservices;
import com.cg.payroll.beans.Associate;
public class PayrollDAOServicesImpl {
	
	private static Associate[]associateList=new Associate[10];
	private static int ASSOCIATE_ID_COUNTER=111;
	private static int ASSOCIATE_IDX_COUNTER=0;
	
	int insertAssociate(Associate associate){
		associate.setAssociateID(ASSOCIATE_ID_COUNTER);
		ASSOCIATE_ID_COUNTER++;
		associateList[ASSOCIATE_IDX_COUNTER++]=associate;
		return associate.getAssociateID();
	}
	boolean updateAssociate(Associate associate){
		return true;
	}
	boolean deleteAssociate(int associateId){
		return false;
	}
	Associate getAssociate(int associateId){
		return null;
	}
	Associate[] getAssociate(){
		return null;
	}
}
