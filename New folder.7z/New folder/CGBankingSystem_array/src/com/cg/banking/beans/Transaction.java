package com.cg.banking.beans;
public class Transaction {
	private int transactionId; float amount;
	private int transactionIdCounter=1;
	private int trasactionIdxCounter=00;
	private String timeStamp,transactionType,transactionLocation,modeOfTransation, transactionStatus;
	
	
	
	
	public Transaction(float amount) {
		super();
		this.amount = amount;
	}

	public Transaction(int transactionId, float amount, int transactionIdCounter, int trasactionIdxCounter,
			String timeStamp, String transactionType, String transactionLocation, String modeOfTransation,
			String transactionStatus) {
		super();
		this.transactionId = transactionId;
		this.amount = amount;
		this.transactionIdCounter = transactionIdCounter;
		this.trasactionIdxCounter = trasactionIdxCounter;
		this.timeStamp = timeStamp;
		this.transactionType = transactionType;
		this.transactionLocation = transactionLocation;
		this.modeOfTransation = modeOfTransation;
		this.transactionStatus = transactionStatus;
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	public int getTransactionIdCounter() {
		return transactionIdCounter;
	}

	public void setTransactionIdCounter(int transactionIdCounter) {
		this.transactionIdCounter = transactionIdCounter;
	}

	public int getTrasactionIdxCounter() {
		return trasactionIdxCounter;
	}

	public void setTrasactionIdxCounter(int trasactionIdxCounter) {
		this.trasactionIdxCounter = trasactionIdxCounter;
	}

	public String getTimeStamp() {
		return timeStamp;
	}

	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getTransactionLocation() {
		return transactionLocation;
	}

	public void setTransactionLocation(String transactionLocation) {
		this.transactionLocation = transactionLocation;
	}

	public String getModeOfTransation() {
		return modeOfTransation;
	}

	public void setModeOfTransation(String modeOfTransation) {
		this.modeOfTransation = modeOfTransation;
	}

	public String getTransactionStatus() {
		return transactionStatus;
	}

	public void setTransactionStatus(String transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Float.floatToIntBits(amount);
		result = prime * result + ((modeOfTransation == null) ? 0 : modeOfTransation.hashCode());
		result = prime * result + ((timeStamp == null) ? 0 : timeStamp.hashCode());
		result = prime * result + transactionId;
		result = prime * result + transactionIdCounter;
		result = prime * result + ((transactionLocation == null) ? 0 : transactionLocation.hashCode());
		result = prime * result + ((transactionStatus == null) ? 0 : transactionStatus.hashCode());
		result = prime * result + ((transactionType == null) ? 0 : transactionType.hashCode());
		result = prime * result + trasactionIdxCounter;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Transaction other = (Transaction) obj;
		if (Float.floatToIntBits(amount) != Float.floatToIntBits(other.amount))
			return false;
		if (modeOfTransation == null) {
			if (other.modeOfTransation != null)
				return false;
		} else if (!modeOfTransation.equals(other.modeOfTransation))
			return false;
		if (timeStamp == null) {
			if (other.timeStamp != null)
				return false;
		} else if (!timeStamp.equals(other.timeStamp))
			return false;
		if (transactionId != other.transactionId)
			return false;
		if (transactionIdCounter != other.transactionIdCounter)
			return false;
		if (transactionLocation == null) {
			if (other.transactionLocation != null)
				return false;
		} else if (!transactionLocation.equals(other.transactionLocation))
			return false;
		if (transactionStatus == null) {
			if (other.transactionStatus != null)
				return false;
		} else if (!transactionStatus.equals(other.transactionStatus))
			return false;
		if (transactionType == null) {
			if (other.transactionType != null)
				return false;
		} else if (!transactionType.equals(other.transactionType))
			return false;
		if (trasactionIdxCounter != other.trasactionIdxCounter)
			return false;
		return true;
	}
	

}
