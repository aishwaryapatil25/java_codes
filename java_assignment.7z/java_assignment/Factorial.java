public class factorial{
	public static void main(String [] str){
		int fact=1;
		int n=5;
		for(int i=1;i<=n;i++)
		fact=fact*i;	
		System.out.print("Factorial of " +n+ " is: " + fact);
	}