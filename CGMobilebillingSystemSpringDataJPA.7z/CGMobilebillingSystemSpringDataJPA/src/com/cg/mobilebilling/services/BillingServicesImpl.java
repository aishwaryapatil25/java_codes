package com.cg.mobilebilling.services;

import java.util.List;

import javax.transaction.Transactional;
import javax.transaction.Transactional.TxType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.mobilebilling.beans.Address;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.BillingDAOServices;
import com.cg.mobilebilling.daoservices.BillingDAOServicesBill;
import com.cg.mobilebilling.daoservices.BillingDAOServicesCustomer;
import com.cg.mobilebilling.daoservices.BillingDAOServicesPlan;
import com.cg.mobilebilling.daoservices.BillingDAOServicesPostpaidAccount;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
@Component("billingServices")
@Transactional(value=TxType.REQUIRED)
public class BillingServicesImpl implements BillingServices {
	/*@Autowired(required=true)
	private BillingDAOServices daoServices;*/
	@Autowired(required=true)
	private BillingDAOServicesCustomer daoServicesCustomer;
	@Autowired(required=true)
	private BillingDAOServicesBill daoServicesBill;
	@Autowired(required=true)
	private BillingDAOServicesPlan  daoServicesPlan;
	@Autowired(required=true)
	private BillingDAOServicesPostpaidAccount  daoServicesPostpaidAccount;
	
	@Override
	public  void createPlan() {
		daoServicesPlan.save(new Plan(1000, 100, 100, 100, 100, 100, 1, 1, 1, 1, 10, "maharastra", "basicPlan"));
		daoServicesPlan.save(new Plan(2000, 100, 100, 100, 100,100, 2, 2, 2, 2, 20, "maharastra", "middlePlan"));
		daoServicesPlan.save(new Plan(3000, 100, 100, 100, 100, 100, 3, 3, 3, 3, 30, "maharastra", "highPlan"));
	}
	
	@Override
	public List<Plan> getPlanAllDetails() throws BillingServicesDownException {
	
		return null;
	}

	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String emailID, String dateOfBirth,
			String billingAddressCity, String billingAddressState, int billingAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode) throws BillingServicesDownException {
		Customer customer=daoServicesCustomer.save(new Customer(firstName, lastName, emailID, dateOfBirth, new Address(billingAddressPinCode, billingAddressCity, billingAddressState), new Address(homeAddressPinCode, homeAddressCity, homeAddressState)));
		return customer.getCustomerID();
	}

	@Override
	public long openPostpaidMobileAccount(int customerID, int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer=daoServicesCustomer.findOne(customerID);
		Plan plan=daoServicesPlan.findOne(planID);
		PostpaidAccount postPaidAccount1=new PostpaidAccount(plan);
	
		postPaidAccount1.setCustomer(customer);
		PostpaidAccount postPaidAccount=daoServicesPostpaidAccount.save(postPaidAccount1);
		return postPaidAccount.getMobileNo();
	}

	@Override
	public int generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillingServicesDownException, PlanDetailsNotFoundException {
		Customer customer=daoServicesCustomer.findOne(customerID);
		PostpaidAccount postPaidAccount=daoServicesPostpaidAccount.findOne(mobileNo);
		Plan plan=postPaidAccount.getPlan();
		if(noOfLocalSMS>plan.getFreeLocalSMS()) {
			int finalLocalSMS=noOfLocalSMS-plan.getFreeLocalSMS();
		}
		else {
			int finalLocalSMS=0;
		}
		if(noOfStdSMS>plan.getFreeStdSMS()) {
			int finalStdSMS=noOfStdSMS-plan.getFreeStdSMS();
		}
		else {
			int finalStdSMS=0;
		}
		int finalLocalCalls=noOfLocalCalls-plan.getFreeLocalCalls();
		int finalStdCalls=noOfStdCalls-plan.getFreeStdCalls();
		int finalInternetDataUsageUnits=internetDataUsageUnits-plan.getFreeInternetDataUsageUnits();
		return 0;
	}

	@Override
	public Customer getCustomerDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws BillingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException, BillingServicesDownException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			BillDetailsNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID) throws CustomerDetailsNotFoundException,
			PostpaidAccountNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerID)
			throws BillingServicesDownException, CustomerDetailsNotFoundException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			PlanDetailsNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}

}