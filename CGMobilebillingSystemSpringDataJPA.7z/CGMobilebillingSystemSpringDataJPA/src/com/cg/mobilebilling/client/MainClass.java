package com.cg.mobilebilling.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.services.BillingServices;
import com.cg.mobilebilling.services.BillingServicesImpl;

public class MainClass {
	public static void main(String[] args) throws BillingServicesDownException, PlanDetailsNotFoundException, CustomerDetailsNotFoundException{
		ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbeans.xml");
		BillingServices billingServices=(BillingServices)applicationContext.getBean("billingServices");
		
		billingServices.createPlan();
		billingServices.acceptCustomerDetails("abhinav", "chikoti", "ganeshm077@gmail.com", "1996/03/30", "pune", "maharastra", 400162, "medak", "telangana", 502110);
		billingServices.openPostpaidMobileAccount(1, 1);
		
	}
}